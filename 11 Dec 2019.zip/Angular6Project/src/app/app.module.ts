import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core'; 
import { ChartsModule } from 'ng2-charts';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateRepositoryComponent } from './Repository/create-repository.component';
import { ListRepositoryComponent } from './Repository/list-repository.component';
import { LoginRepositoryComponent }  from './Repository/login-repository.component';
import { IndividualRepositoryComponent } from './Repository/individual-repository.component';
import { ManagerRepositoryComponent } from './Repository/manager-repository.component';
import { MyBarChartComponent} from './my-bar-chart/my-bar-chart.component';
import { MyPieChartComponent } from './my-pie-chart/my-pie-chart.component';
// import { HttpModule }  from '@angular/http'; 
import { RepositoryService} from './repository.service';
import { HttpClientModule} from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    CreateRepositoryComponent,
    ListRepositoryComponent,
    LoginRepositoryComponent,
    IndividualRepositoryComponent,
    ManagerRepositoryComponent,
    MyBarChartComponent,
    MyPieChartComponent
  ],
  imports: [
    BrowserModule,  
    AppRoutingModule,
    ChartsModule,
    // HttpModule
    HttpClientModule
  ],
  providers: [
    RepositoryService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
