export class Blogpost {
    id : number;
    title : string;
    description : string;
    author : string;
}
