import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListRepositoryComponent } from './Repository/list-repository.component';
import { CreateRepositoryComponent } from './Repository/create-repository.component';
import { LoginRepositoryComponent } from './Repository/login-repository.component';
import { IndividualRepositoryComponent } from './Repository/individual-repository.component';
import { ManagerRepositoryComponent } from './Repository/manager-repository.component';
import { MyBarChartComponent } from './my-bar-chart/my-bar-chart.component';
import { MyPieChartComponent } from './my-pie-chart/my-pie-chart.component';


const routes: Routes = [
  { path : 'RegisterForm', component: CreateRepositoryComponent },
  { path : 'login', component: LoginRepositoryComponent },
  { path : 'list', component: ListRepositoryComponent },
  { path : 'Individual', component: IndividualRepositoryComponent },
  { path : 'Manager', component: ManagerRepositoryComponent },
  { path : 'bar-chart', component: MyBarChartComponent },
  { path : 'pie-chart', component: MyPieChartComponent },
  { path : '',redirectTo: '/login',pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
