import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-bar-chart',
  templateUrl: './my-bar-chart.component.html',
  styleUrls: ['./my-bar-chart.component.css']
})
export class MyBarChartComponent implements OnInit {

  public barChartOptions ={
    scaleShowVerticalLines : false,
    responsive : true

  };

  public barChartLebels = ['Rupesh','Divya','Suyog','2017','2018','2019'];
  public barChartType = 'bar';
  public barChartLegand = true;
  public barChartData = [
    {data : [120, 200, 150, 30, 50, 90], label : 'Bilable'},
    {data : [100, 100, 40, 30, 100, 90], label : 'Non Bilable'}
    // {data : [20, 70, 140, 100, 160, 180], label : 'Leave'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
