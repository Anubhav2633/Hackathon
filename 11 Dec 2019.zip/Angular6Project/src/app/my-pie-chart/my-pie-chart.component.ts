import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-pie-chart',
  templateUrl: './my-pie-chart.component.html',
  styleUrls: ['./my-pie-chart.component.css']
})
export class MyPieChartComponent implements OnInit {

  public pieChartLebels = ['Coding','Trainning','Leave','Other'];
  public pieChartData = [120, 150,180,50];
  public pieChartType = 'pie';

  

  constructor() { }

  ngOnInit() {
  }

}
