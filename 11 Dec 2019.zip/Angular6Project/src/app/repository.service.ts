import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { componentFactoryName } from '@angular/compiler';
import { Blogpost } from './blogpost';

@Injectable({
  providedIn: 'root'
})
export class RepositoryService {

  serverUrl = 'http://localhost:51025/';

  printToConsole(arg){
    console.log(arg);
  }

  constructor(private http : HttpClient) { }
  getBolgPosts()
  {
    return this.http.get<Blogpost>(this.serverUrl + 'RepositoryController/Get')
    .pipe(
      // catchError (this.haddleError) ;

    );
  }
}
