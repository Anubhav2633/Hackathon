import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Router} from '@angular/router'

@Component({
  selector: 'app-create-repository',
  templateUrl: './create-repository.component.html',
  styleUrls: ['./create-repository.component.css']
})
export class CreateRepositoryComponent implements OnInit {
  

  constructor(private _router : Router) { }

  SumbitRegistrationForm(): void {
    this._router.navigate(['login']);
  }

  ngOnInit() {
  }

}
