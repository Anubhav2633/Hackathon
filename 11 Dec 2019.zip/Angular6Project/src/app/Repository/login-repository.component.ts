import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Router} from '@angular/router'
import {RepositoryService} from '../repository.service';
import {Blogpost} from '../blogpost';

@Component({
  selector: 'app-login-repository',
  templateUrl: './login-repository.component.html',
  styleUrls: ['./login-repository.component.css']
})
export class LoginRepositoryComponent implements OnInit {

  posts : Blogpost[];
  error : string ;
  
  constructor(private _router : Router, private repositoryService: RepositoryService) { }

  SumbitButtonFuction(event): void {
    
  if (event =="Manager") 
 {
     this._router.navigate(['/bar-chart']);
 }
 else 
 {
     this._router.navigate(['/pie-chart']);
 }

}
  //   this._router.navigate(['/bar-chart']);
  // }

  // SumbitButtonFuction1(): void {
  //   this._router.navigate(['/pie-chart']);
  // }

  ngOnInit() {
    this.repositoryService.getBolgPosts().subscribe(
      (data: null) => this.posts = data,
      error => this.error =  error
      
    );

  }

  loginuser(event)
  {
    event.prventDefault() 
    console.log(event);
  }  
}
