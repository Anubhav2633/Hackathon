import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-repository',
  templateUrl: './list-repository.component.html',
  styleUrls: ['./list-repository.component.css']
})
export class ListRepositoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
