import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-pie-chart',
  templateUrl: './my-pie-chart.component.html',
  styleUrls: ['./my-pie-chart.component.css']
})
export class MyPieChartComponent implements OnInit {

  public pieChartLebels = ['sales 01','sales 02','sales 03','sales 04'];
  public pieChartData = [120, 150,180,90];
  public pieChartType = 'pie';

  constructor() { }

  ngOnInit() {
  }

}
