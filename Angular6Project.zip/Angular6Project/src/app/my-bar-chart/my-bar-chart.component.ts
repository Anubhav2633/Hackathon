import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-bar-chart',
  templateUrl: './my-bar-chart.component.html',
  styleUrls: ['./my-bar-chart.component.css']
})
export class MyBarChartComponent implements OnInit {

  public barChartOptions ={
    scaleShowVerticalLines : false,
    responsive : true

  };

  public barChartLebels = ['2011','2012','2013','2014','2015','2016'];
  public barChartType = 'bar';
  public barChartLegand = true;   
  public barChartData = [
    {data : [50, 70, 50, 30, 50, 90, 50, 240], label : 'Series A'}, 
    {data : [50, 100, 40, 30, 0, 90, 110, 20], label : 'Series B'},
    {data : [50, 70, 140, 30, 60, 90, 50, 120], label : 'Series C'} 
  ];

  constructor() { }

  ngOnInit() {  
  }

}
