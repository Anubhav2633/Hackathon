import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-repository',
  templateUrl: './login-repository.component.html',
  styleUrls: ['./login-repository.component.css']
})
export class LoginRepositoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  loginuser(event)
  {
    event.prventDefault() 
    console.log(event);
  }  
}
