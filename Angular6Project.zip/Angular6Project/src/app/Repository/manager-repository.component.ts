import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-repository',
  templateUrl: './manager-repository.component.html',
  styleUrls: ['./manager-repository.component.css']
})
export class ManagerRepositoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
