import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individual-repository',
  templateUrl: './individual-repository.component.html',
  styleUrls: ['./individual-repository.component.css']
})
export class IndividualRepositoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
